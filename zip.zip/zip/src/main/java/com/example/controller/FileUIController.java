package com.example.controller;

import com.example.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/")
public class FileUIController {

    private final FileService fileService;

    @Autowired
    public FileUIController(FileService fileService) {
        this.fileService = fileService;
    }

    @GetMapping
    public String showFileForm() {
        return "index"; // Return the logical view name, not the physical path
    }

    @GetMapping("/encrypt")
    public String showEncryptForm() {
        return "encrypt";
    }

    @GetMapping("/decrypt")
    public String showDecryptForm() {
        return "decrypt";
    }

    @PostMapping("/performOperation")
    public String handleFileOperation(
            @RequestParam("inputFile") String inputFile,
            @RequestParam("password") String password,
            @RequestParam("operation") String operation,
            RedirectAttributes redirectAttributes
    ) {
        try {
            String outputFile;
            String successMessage;

            if ("encrypt".equals(operation)) {
                outputFile = "path/to/encrypted_file.enc";
                fileService.encryptFile(inputFile, outputFile, password);
                successMessage = "File encrypted successfully!";
                redirectAttributes.addFlashAttribute("encryptedFile", outputFile);
            } else if ("decrypt".equals(operation)) {
                outputFile = "path/to/decrypted_file.txt";
                fileService.decryptFile(inputFile, outputFile, password);
                successMessage = "File decrypted successfully!";
                redirectAttributes.addFlashAttribute("decryptedFile", outputFile);
            } else {
                throw new IllegalArgumentException("Invalid operation: " + operation);
            }

            redirectAttributes.addFlashAttribute("successMessage", successMessage);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error processing file: " + e.getMessage());
        }

        return "redirect:/" + operation;
    }
}
