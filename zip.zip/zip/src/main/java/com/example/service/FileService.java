package com.example.service;

import com.example.util.FileEncryptor;
import org.springframework.stereotype.Service;

@Service
public class FileService {

    public void encryptFile(String inputFile, String outputFile, String password) throws Exception {
        try {
            FileEncryptor.encryptFile(inputFile, outputFile, password);
        } catch (Exception e) {
            throw new Exception("Error encrypting file: " + e.getMessage(), e);
        }
    }

    public void decryptFile(String inputFile, String outputFile, String password) throws Exception {
        try {
            FileEncryptor.decryptFile(inputFile, outputFile, password);
        } catch (Exception e) {
            throw new Exception("Error decrypting file: " + e.getMessage(), e);
        }
    }
}
